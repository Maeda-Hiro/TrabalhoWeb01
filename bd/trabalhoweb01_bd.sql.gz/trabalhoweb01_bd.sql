CREATE DATABASE IF NOT EXISTS `trabalhoweb01_bd` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;

USE `trabalhoweb01_bd`;

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";
SET NAMES utf8mb4;

CREATE TABLE `usuarios` (
  `email` varchar(256) NOT NULL,
  `senha` varchar(256) NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(100) NOT NULL,
  `rg` int(10) NOT NULL,
  `cpf` int(11) NOT NULL,
  `endereco` varchar(100) NOT NULL,
  `fone` int(10) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `rg` (`rg`),
  UNIQUE KEY `cpf` (`cpf`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `comentarios` (
  `id_comentario` int(100) NOT NULL AUTO_INCREMENT,
  `id_usuario` int(100) NOT NULL,
  `data_coment` date NOT NULL,
  `descricao` varchar(280) NOT NULL,
  PRIMARY KEY (`id_comentario`),
  KEY `id_usuario` (`id_usuario`),
  CONSTRAINT `comentarios_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `dados_bancarios` (
  `id_dados_bancarios` int(100) NOT NULL AUTO_INCREMENT,
  `id_usuario` int(100) NOT NULL,
  `n_cartao` bigint(16) NOT NULL,
  `nome_cartao` varchar(64) NOT NULL,
  `ccv` int(3) NOT NULL,
  `validade` varchar(7) NOT NULL,
  `pix` varchar(256) NOT NULL,
  PRIMARY KEY (`id_dados_bancarios`),
  UNIQUE KEY `n_cartao` (`n_cartao`),
  KEY `id_usuario` (`id_usuario`),
  CONSTRAINT `dados_bancarios_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
  